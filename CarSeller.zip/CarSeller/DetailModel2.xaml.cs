﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CarSeller
{
    /// <summary>
    /// Logique d'interaction pour DetailModel2.xaml
    /// </summary>
    public partial class DetailModel2 : Window
    {

        // DetailModel2 :  Utilisation d'une autre méthode
        public DetailModel2()
        {
            InitializeComponent();

            //Création d'une liste de voiture 
            List<Cars> items = new List<Cars>();

            //Création de l'objet C qui est une voiture 
            Cars C = new Cars("Voiture 1", 2, 15, 200);

            //Ajout dans la liste de voiture
            items.Add(C);
            
            // 
            lsCars.ItemsSource = items;
        }

        public class Cars
        {
            //Champs de la classe
            private String Nom;
            private int Chevaux;
            private int Places;
            private int Prix;

            //Constructeur 
            public Cars(String Nom, int Chevaux, int Places, int Prix)
            {
                this.Nom = Nom;
                this.Chevaux = Chevaux;
                this.Places = Places;
                this.Prix = Prix;
            }

            //Méthodes ..

        }
    }
}
