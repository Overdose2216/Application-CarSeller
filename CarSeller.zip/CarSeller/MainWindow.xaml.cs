﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;
using System.IO;

namespace CarSeller
{
    /// <summary>
    /// Logique d'interaction pour MainWindow.xaml
    /// </summary>
    public partial class MainWindow : NavigationWindow
    {
        
        public MainWindow()
        {
            InitializeComponent();

            // ############  Début Trie  ############# //

            int[] tab = new int[100000];             // Création du tableau d'entiers
            Random rndm = new Random();              // Variable de type Random
            for (int i = 0; i < tab.Length; i++)    // Parcours du tableau
            {
               
                int Nombre = rndm.Next(0, 100000); // Nombre aléatoire
                tab[i] = Nombre;                  //  Tableau rempli de manière aléatoire avec des nombres compris entre 0 & 100 000
            }

            

            //Trie du tableau par insertion 
            int ii, temp, indice;
            bool verif;                          //déclarations variables

            for (ii = 1; ii < tab.Length; ii++)
            {
                temp = tab[ii];
                indice = ii - 1;

                do
                {
                    verif = false;
                    if (tab[indice] > temp)                // si la valeur est suppérieur à la variable temporaire,
                    {
                        tab[indice + 1] = tab[indice];     // on ajoute cette valeur  à la case d'après
                        indice--;                         //  décrémentation 
                        verif = true;
                    }
                    if (indice < 0) verif = false;
                }
                while (verif);
                tab[indice + 1] = temp;                 // Ajout de la variable temporaire 
            }

            for (int m = 0; m < tab.Length; m++)
            {
                Console.WriteLine("contenu du tableau Après trie : " + tab[m]);
            }


            // ############  Début Fibonacci  ############# //

            Console.WriteLine("Début de la 2èm Thread: ");
            Thread f = new Thread(new ThreadStart(Fibonacci));
            f.Start();


            Console.WriteLine("Début de la 3èm Thread: ");
            Thread p = new Thread(new ThreadStart(Palindrome));
             p.Start();
            //Console.WriteLine("RES palindrome: " + IsPalindrome("Elle"));

            Console.WriteLine("Thread 1 finie !! ");

            // ############  FIN Trie  ############# //
            Console.ReadLine();

           

        }

        // ############  Fibonacci  ############# //
        public static void Fibonacci()
        {
            
            int fib(int n)
            {

                if (n <= 1)
                    return 1;
                else
                    return fib(n - 1) + fib(n - 2);
            }

           

            // Suite de Fibonacci dans le fichier txt
            string path = @"c:\temp\Fibonacci.txt";
            if (!File.Exists(path))
            {
                // Create a file to write to.
                using (StreamWriter sw = File.CreateText(path))
                {
                  
                    for (int i = 0; i < 20; i++)
                    {
                        sw.WriteLine(fib(i));
                    }
                }
            }
            Console.WriteLine("Thread 2 finie !! ");
        }


        // ############  FIN  Fibonacci  ############# //



        // ############  Palindrome  ############# //
        public static void Palindrome()
        {
            Random rnd = new Random();
            Random rndm = new Random();
            String[] TabMots = new string[50000];
            string mot;
            int taille;
            char randomChar;                                // Déclarations des variables

            for (int i = 0; i < TabMots.Length; i++)        // Parcours du tableau de mots
           {
               
                taille = rndm.Next(2, 7);                   // taille du mot aléatoire entre 2 et 7 
                mot = "";

                for (int ii = 0; ii < taille; ii++)         // début parcours pour créer le mot 
                {


                     randomChar = (char)rnd.Next('a', 'n');     // lettres aléatoire ente a & n 
                    mot = mot + randomChar;                     // Concaténation des lettres

                }
                TabMots[i] = mot;                               // Ajout du mot dans le tableau de mots 

              
            }

            // Vérification des mots dans le fichier txt
            string rep2 = "Non";
            string path = @"c:\temp\Palindrome.txt";
            if (!File.Exists(path))
            {
                // Create a file to write to.
                using (StreamWriter sw = File.CreateText(path))
                {

                    for (int mm = 0; mm < TabMots.Length; mm++)
                    {
                        
                        sw.WriteLine("Mot du tableau:  " + TabMots[mm]);
                        if (IsPalindrome(TabMots[mm]))
                            rep2 = "Oui";

                        sw.WriteLine("Est-ce un Palindrome ?  " + rep2);
                        rep2 = "Non";
                    }
                }
            }

            // Lecture du fichier
            using (StreamReader sr = File.OpenText(path))
            {
                string s = "";
                while ((s = sr.ReadLine()) != null)
                {
                    Console.WriteLine(s);
                }
            }

            Console.WriteLine("Thread 3 finie !! ");
        }

        // ############  FIN Palindrome  ############# //

        // Fonction qui vérifie si le mot passé en paramètre  est un Palindrome
        public static bool IsPalindrome(string word)
        {
            string first = word.Substring(0, word.Length / 2);
            char[] arr = word.ToCharArray();
            Array.Reverse(arr);
            string temp = new string(arr);
            string second = temp.Substring(0, temp.Length / 2);
            return first.Equals(second);
            
        }

    }
}
