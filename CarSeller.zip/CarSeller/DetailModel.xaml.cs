﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CarSeller
{
    /// <summary>
    /// Logique d'interaction pour DetailModel.xaml
    /// </summary>
    public partial class DetailModel : Window
    {
        public DetailModel()
        {
            InitializeComponent();
            List<Cars> items = new List<Cars>();
            items.Add(new Cars() { Nom = "Voiture 1", Chevaux = 80, Places = 5, Prix = 3500 });
            items.Add(new Cars() { Nom = "Voiture 2", Chevaux = 100, Places = 4, Prix = 4863 });
            items.Add(new Cars() { Nom = "Voiture 3", Chevaux = 50, Places = 4, Prix = 1436 });
            lsCars.ItemsSource = items;
        }

        public class Cars
        {
            

            public string Nom { get; set; }

            public int Chevaux { get; set; }

            public int Places { get; set; }

            public int Prix { get; set; }
        }
    }
}
